
public class AdaLovelace {

    public static void main(String[] args) {
        System.out.println("Ada Lovelace");
    }
}
